package com.fundamental.githubapp.Favorite

import androidx.room.Database
import androidx.room.RoomDatabase
import com.fundamental.githubapp.data.UsrEntity

@Database(entities = [UsrEntity::class], version = 1, exportSchema = false)
abstract class FavDB : RoomDatabase() {
    abstract fun favDao(): FavDao
}