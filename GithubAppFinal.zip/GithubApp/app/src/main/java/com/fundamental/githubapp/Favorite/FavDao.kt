package com.fundamental.githubapp.Favorite

import androidx.room.*
import com.fundamental.githubapp.data.UsrEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(usrEntity: UsrEntity)

    @Update
    suspend fun update(usrEntity: UsrEntity)

    @Delete
    suspend fun delete(usrEntity: UsrEntity)

    @Query("SELECT * FROM user ORDER BY id ASC")
    fun getUserList(): Flow<List<UsrEntity>>

    @Query("SELECT EXISTS(SELECT * FROM user WHERE id = :id AND it_fav = 1)")
    fun itFavUser(id: String): Flow<Boolean>
}