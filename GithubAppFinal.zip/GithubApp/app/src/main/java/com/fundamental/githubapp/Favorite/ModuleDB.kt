package com.fundamental.githubapp.Favorite

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleDB {

    @Provides
    fun provideFavDao(favDB: FavDB): FavDao = favDB.favDao()

    @Provides
    @Singleton
    fun provideFavDB(@ApplicationContext context: Context): FavDB {
        return Room.databaseBuilder(
            context.applicationContext,
            FavDB::class.java,
            "fav_db"
        ).build()
    }
}