package com.fundamental.githubapp.data.remote.response

import com.google.gson.annotations.SerializedName

data class userResponse(

    @field:SerializedName("items")
    val items: ArrayList<UserX>
)

data class User(

    @field:SerializedName("login")
    val login: String,

    @field:SerializedName("name")
    val name: String?,

    @field:SerializedName("company")
    val company: String?,

    @field:SerializedName("location")
    val location: String?,

    @field:SerializedName("followers")
    val followers: Int,

    @field:SerializedName("following")
    val following: Int,

    @field:SerializedName("avatar_url")
    val avatarUrl: String,

    @field:SerializedName("html_url")
    val htmlUrl: String,

    @field:SerializedName("usr_repos")
    val usrRepos: Int,
)

data class UserX(

    @field:SerializedName("avatar_url")
    val avatarUrl: String,

    @field:SerializedName("login")
    val login: String
)


