package com.fundamental.githubapp.data.remote.retrofit

import com.fundamental.githubapp.data.remote.retrofit.ApiConfig
import com.fundamental.githubapp.data.remote.retrofit.ApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ApiModule {

    @Provides
    @Singleton
    fun provService(): ApiService = ApiConfig.getService()
}