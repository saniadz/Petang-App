package com.fundamental.githubapp.data.remote.retrofit

import com.fundamental.githubapp.data.remote.response.User
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.data.remote.response.userResponse
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    suspend fun unameSearch(
        @Header("Authorization") token: String,
        @Query("q") q: String
    ): userResponse

    @GET("users/{username}")
    suspend fun getDetailUsr(
        @Header("Authorization") token: String,
        @Path("username") username: String
    ): User

    @GET("users/{username}/followers")
    suspend fun getUsrFllwers(
        @Header("Authorization") token: String,
        @Path("username") username: String
    ): ArrayList<UserX>

    @GET("users/{username}/following")
    suspend fun getUsrFllwing(
        @Header("Authorization") token: String,
        @Path("username") username: String
    ): ArrayList<UserX>
}