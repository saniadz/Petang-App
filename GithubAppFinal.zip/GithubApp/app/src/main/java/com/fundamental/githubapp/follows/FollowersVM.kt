package com.fundamental.githubapp.follows

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.remote.response.UserX
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FollowersVM @Inject constructor(private val repo: Repo) : ViewModel() {

    private val load = MutableStateFlow(false)
    val loadData = load.asStateFlow()

    private val fllwers = MutableStateFlow<Result<ArrayList<UserX>>>(Result.Loading)
    val followers = fllwers.asStateFlow()

    fun getFllwers(uname: String) {
        fllwers.value = Result.Loading
        viewModelScope.launch {
            repo.getUsrFllwers(uname).collect {
                fllwers.value = it
            }
        }

        load.value = true
    }
}