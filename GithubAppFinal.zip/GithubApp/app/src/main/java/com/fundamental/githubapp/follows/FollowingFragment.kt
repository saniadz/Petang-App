package com.fundamental.githubapp.follows

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.fundamental.githubapp.view.UserAdapter
import com.fundamental.githubapp.view.PagerAdapter.Companion.ARGS_USERNAME
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.databinding.FollowingFragmentBinding
import com.fundamental.githubapp.view.detail.DetailUserActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FollowingFragment : Fragment() {

    private var bind: FollowingFragmentBinding? = null
    private val _bind get() = bind!!

    private val followingVM: FollowingVM by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FollowingFragmentBinding.inflate(layoutInflater, container, false)
        return _bind.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val uname = arguments?.getString(ARGS_USERNAME) ?: ""
        viewLifecycleOwner.lifecycleScope.launchWhenStarted {
            launch {
                followingVM.following.collect {
                    onFollowingResultReceived(it)
                }
            }
            launch {
                followingVM.isLoad.collect { loadData ->
                    if (!loadData) followingVM.getUsrFllwing(uname)
                }
            }
        }
    }

    override fun onDestroy() {
        bind = null
        super.onDestroy()
    }

    private fun onFollowingResultReceived(fllwingResult: Result<ArrayList<UserX>>) {
        when (fllwingResult) {
            is Result.Loading -> showLoading(true)
            is Result.Error -> {
                showLoading(false)
            }
            is Result.Success -> {
                showFollowing(fllwingResult.data)
                showLoading(false)
            }
        }
    }

    private fun showFollowing(usrs: ArrayList<UserX>) {
        if (usrs.size > 0) {
            val llManager = LinearLayoutManager(activity)
            val adapters = UserAdapter(usrs)

            _bind.rvList.apply {
                layoutManager = llManager
                adapter = adapters
                setHasFixedSize(true)
            }

            adapters.setOnItemClickCallback(object :
                UserAdapter.OnItemClickCallback {
                override fun onItemClicked(user: UserX) {
                    goToDetailUser(user)
                }

            })
        } else _bind.tvFollowingStatus.visibility = View.VISIBLE
    }

    private fun showLoading(loadData: Boolean) {
        if (loadData) _bind.pbFollowing.visibility = View.VISIBLE
        else _bind.pbFollowing.visibility = View.GONE
    }

    private fun goToDetailUser(usr: UserX) {
        Intent(activity, DetailUserActivity::class.java).apply {
            putExtra(DetailUserActivity.EXTRA_DETAIL, usr.login)
        }.also {
            startActivity(it)
        }
    }
}