package com.fundamental.githubapp.follows

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.remote.response.UserX
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FollowingVM @Inject constructor(private val repo: Repo) : ViewModel() {

    private val _load = MutableStateFlow(false)
    val isLoad = _load.asStateFlow()

    private val fllwing = MutableStateFlow<Result<ArrayList<UserX>>>(Result.Loading)
    val following = fllwing.asStateFlow()

    fun getUsrFllwing(uname: String) {
        fllwing.value = Result.Loading
        viewModelScope.launch {
            repo.getUsrFllwing(uname).catch { e ->
                fllwing.value = Result.Error(e.message.toString())
            }.collect {
                fllwing.value = it
            }
        }
        _load.value = true
    }
}