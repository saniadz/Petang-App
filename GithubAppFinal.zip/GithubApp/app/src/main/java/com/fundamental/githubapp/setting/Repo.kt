package com.fundamental.githubapp.setting

import android.util.Log
import com.fundamental.githubapp.BuildConfig
import com.fundamental.githubapp.Favorite.FavDao
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.UsrEntity
import com.fundamental.githubapp.data.remote.response.User
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.data.remote.retrofit.ApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class Repo @Inject constructor(
    private val apiService: ApiService,
    private val favDao: FavDao,
    private val pref: SettingPreferences
) {

    fun userSearch(q: String): Flow<Result<ArrayList<UserX>>> = flow {
        emit(Result.Loading)
        try {
            val usrs = apiService.unameSearch(token = API_TOKEN, q).items
            emit(Result.Success(usrs))
        } catch (e: Exception) {
            Log.d(TAG, "userSearch: ${e.message.toString()}")
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getUsrFllwing(id: String): Flow<Result<ArrayList<UserX>>> = flow {
        emit(Result.Loading)
        try {
            val usrs = apiService.getUsrFllwing(token = API_TOKEN, id)
            emit(Result.Success(usrs))
        } catch (e: Exception) {
            Log.d(TAG, "getUsrFllwing: ${e.message.toString()}")
            emit(Result.Error(e.message.toString()))
        }
    }
    fun getUsrFllwers(id: String): Flow<Result<ArrayList<UserX>>> = flow {
        emit(Result.Loading)
        try {
            val usrs = apiService.getUsrFllwers(token = API_TOKEN, id)
            emit(Result.Success(usrs))
        } catch (e: Exception) {
            Log.d(TAG, "getUsrFllwers: ${e.message.toString()}")
            emit(Result.Error(e.message.toString()))
        }
    }

    fun getDetailProfile(id: String): Flow<Result<User>> = flow {
        emit(Result.Loading)
        try {
            val usr = apiService.getDetailUsr(token = API_TOKEN, id)
            emit(Result.Success(usr))
        } catch (e: Exception) {
            Log.d(TAG, "getDetailProfile: ${e.message.toString()}")
            emit(Result.Error(e.message.toString()))
        }
    }

    fun itFavUser(id: String): Flow<Boolean> = favDao.itFavUser(id)

    fun getFavList(): Flow<List<UsrEntity>> = favDao.getUserList()

    suspend fun delFav(user: UsrEntity) {
        favDao.delete(user)
    }

    suspend fun saveUsrFav(user: UsrEntity) {
        favDao.insert(user)
    }

    fun getSetTheme(): Flow<Boolean> = pref.getThemeSet()

    suspend fun saveThemeSet(isDarkModeActive: Boolean) {
        pref.saveThemeSet(isDarkModeActive)
    }

    companion object {
        private const val API_TOKEN = "Bearer ${BuildConfig.API_KEY}"
        private val TAG = Repo::class.java.simpleName
    }
}