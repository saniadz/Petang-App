package com.fundamental.githubapp.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.databinding.ItemRowBinding
import com.fundamental.githubapp.utils.Helper.Companion.setImageGlide


class UserAdapter(private val usrList: ArrayList<UserX>) : RecyclerView.Adapter<UserAdapter.ListViewHolder>() {

    private lateinit var onICCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onICCallback = onItemClickCallback
    }

    class ListViewHolder(var bind: ItemRowBinding) : RecyclerView.ViewHolder(bind.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ListViewHolder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(lvHolder: ListViewHolder, position: Int) {
        val usr = usrList[position]

        lvHolder.bind.apply {
            idUname.text = usr.login
            imgAva.setImageGlide(lvHolder.itemView.context, usr.avatarUrl)
        }

        lvHolder.itemView.setOnClickListener { onICCallback.onItemClicked(usr) }
    }

    override fun getItemCount(): Int = usrList.size

    interface OnItemClickCallback {
        fun onItemClicked(user: UserX)
    }
}
