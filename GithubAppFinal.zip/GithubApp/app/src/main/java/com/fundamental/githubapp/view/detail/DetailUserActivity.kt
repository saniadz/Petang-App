package com.fundamental.githubapp.view.detail

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.viewpager2.widget.ViewPager2
import com.fundamental.githubapp.R
import com.fundamental.githubapp.view.PagerAdapter
import com.fundamental.githubapp.data.UsrEntity
import com.fundamental.githubapp.data.remote.response.User
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.databinding.UserDetailBinding
import com.fundamental.githubapp.utils.EspressoIdlingResource
import com.fundamental.githubapp.utils.Helper.Companion.setAndVisible
import com.fundamental.githubapp.utils.Helper.Companion.setImageGlide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DetailUserActivity : AppCompatActivity(), View.OnClickListener {

    private var _bind: UserDetailBinding? = null
    private val bind get() = _bind!!

    private var username: String? = null
    private var profileUrl: String? = null
    private var usrDetail: UsrEntity? = null
    private var itFav: Boolean? = false

    private val detailVM: DetailVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _bind = UserDetailBinding.inflate(layoutInflater)
        username = intent.extras?.get(EXTRA_DETAIL) as String

        setContentView(bind.root)
        setTB(getString(R.string.profile_pic))
        setVP()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    detailVM.usrDetail.collect { detailResult ->
                        onDetailData(detailResult)
                    }
                }
                launch {
                    detailVM.itFavUser(username ?: "").collect { detailState ->
                        itFavUser(detailState)
                        itFav = detailState
                    }
                }
                launch {
                    detailVM.loadData.collect { loadData ->
                        if (!loadData) detailVM.getProfileDetail(username ?: "")
                    }
                }
            }
        }

        bind.fabFav.setOnClickListener(this)
    }

    override fun onStart() {
        super.onStart()
        EspressoIdlingResource.increment()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.fab_fav -> {
                if (itFav == true) {
                    usrDetail?.let { detailVM.delFav(it) }
                    itFavUser(false)
                    Toast.makeText(this, "unfavorite user", Toast.LENGTH_SHORT).show()
                } else {
                    usrDetail?.let { detailVM.saveFavUser(it) }
                    itFavUser(true)
                    Toast.makeText(this, "add to favorite", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        _bind = null
        username = null
        profileUrl = null
        itFav = null
        super.onDestroy()
    }

    private fun onDetailData(dataResult: Result<User>) {
        when (dataResult) {
            is Result.Loading -> showLoading(true)
            is Result.Error -> {
                showError()
                showLoading(false)
                Toast.makeText(this, dataResult.error, Toast.LENGTH_SHORT).show()
            }
            is Result.Success -> {
                dataResult.data.let { usr ->
                    getDetailProfile(usr)

                    val usrEntity = UsrEntity(
                        usr.login,
                        usr.avatarUrl,
                        true
                    )

                    usrDetail = usrEntity
                    profileUrl = usr.htmlUrl
                }

                showLoading(false)
                EspressoIdlingResource.decrement()
            }
        }
    }

    private fun itFavUser(favData: Boolean) {
        if (favData) {
            bind.fabFav.setImageResource(R.drawable.ic_fav_24)
        } else {
            bind.fabFav.setImageResource(R.drawable.ic_favborder)
        }
    }

    private fun showError() {
        bind.apply {
            idDetail.visibility = View.INVISIBLE
            idTab.visibility = View.INVISIBLE
            vpDetail.visibility = View.INVISIBLE
        }
    }

    private fun setTB(title: String) {
        setSupportActionBar(bind.tbDetail)
        bind.tbCollaps.isTitleEnabled = false
        supportActionBar?.apply {
            setDisplayShowHomeEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            this.title = title
        }
    }

    private fun setVP() {
        val vp: ViewPager2 = bind.vpDetail
        val tLayout: TabLayout = bind.idTab

        vp.adapter = PagerAdapter(this, username!!)

        TabLayoutMediator(tLayout, vp) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
    }

    private fun showLoading(loadData: Boolean) {
        if (loadData) {
            bind.apply {
                pbDetail.visibility = View.VISIBLE
                idAppbar.visibility = View.INVISIBLE
                vpDetail.visibility = View.INVISIBLE
                fabFav.visibility = View.GONE
            }
        } else {
            bind.apply {
                pbDetail.visibility = View.GONE
                idAppbar.visibility = View.VISIBLE
                vpDetail.visibility = View.VISIBLE
                fabFav.visibility = View.VISIBLE
            }
        }
    }

    private fun getDetailProfile(usr: User) {
        bind.apply {
            tvUname.text = usr.login
            tvRepo.text = usr.usrRepos.toString()
            tvDetailFollower.text = usr.followers.toString()
            tvDetailFollowing.text = usr.following.toString()

            tvName.setAndVisible(usr.name)
            tvDetailCompany.setAndVisible(usr.company)
            tvDetailLoc.setAndVisible(usr.location)

            cvAva.setImageGlide(this@DetailUserActivity, usr.avatarUrl)
        }
    }

    companion object {
        const val EXTRA_DETAIL = "extra_detail"
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }
}