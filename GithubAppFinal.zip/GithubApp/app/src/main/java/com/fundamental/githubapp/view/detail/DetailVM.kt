package com.fundamental.githubapp.view.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import com.fundamental.githubapp.data.UsrEntity
import com.fundamental.githubapp.data.remote.response.User
import com.fundamental.githubapp.data.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailVM @Inject constructor(private val repo: Repo) : ViewModel() {

    private val _detail = MutableStateFlow<Result<User>>(Result.Loading)
    val usrDetail = _detail.asStateFlow()

    private val _load = MutableStateFlow(false)
    val loadData = _load.asStateFlow()

    fun getProfileDetail(username: String) {
        _detail.value = Result.Loading
        viewModelScope.launch {
            repo.getDetailProfile(username).collect {
                _detail.value = it
            }
        }

        _load.value = true
    }

    fun saveFavUser(user: UsrEntity) {
        viewModelScope.launch {
            repo.saveUsrFav(user)
        }
    }

    fun delFav(user: UsrEntity) {
        viewModelScope.launch {
            repo.delFav(user)
        }
    }

    fun itFavUser(id: String): Flow<Boolean> = repo.itFavUser(id)
}