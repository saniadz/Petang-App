package com.fundamental.githubapp.view.fav

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.fundamental.githubapp.R
import com.fundamental.githubapp.view.UserAdapter
import com.fundamental.githubapp.data.UsrEntity
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.databinding.FavoriteBinding
import com.fundamental.githubapp.utils.EspressoIdlingResource
import com.fundamental.githubapp.view.detail.DetailUserActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FavActivity : AppCompatActivity() {

    private lateinit var bind: FavoriteBinding
    private val favVM: FavVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bind = FavoriteBinding.inflate(layoutInflater)
        setContentView(bind.root)
        setTB(getString(R.string.fav))

        lifecycleScope.launchWhenStarted {
            launch {
                favVM.favor.collect {
                    EspressoIdlingResource.increment()
                    if (it.isNotEmpty()) showUsrFav(it)
                    else showMsg()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    private fun showMsg() {
        bind.tvMsg.visibility = View.VISIBLE
        bind.rvFav.visibility = View.GONE

        EspressoIdlingResource.decrement()
    }

    private fun showUsrFav(usrs: List<UsrEntity>) {
        val usrList = ArrayList<UserX>()

        usrs.forEach { user ->
            val favData = UserX(
                user.avatarUrl,
                user.id
            )

            usrList.add(favData)
        }

        val usrAdapter = UserAdapter(usrList)

        bind.rvFav.apply {
            layoutManager = LinearLayoutManager(this@FavActivity)
            adapter = usrAdapter
            visibility = View.VISIBLE
            setHasFixedSize(true)
        }

        bind.tvMsg.visibility = View.GONE

        usrAdapter.setOnItemClickCallback(object :
            UserAdapter.OnItemClickCallback {
            override fun onItemClicked(user: UserX) {
                goToProfileDetail(user)
            }
        })

        EspressoIdlingResource.decrement()
    }

    private fun goToProfileDetail(user: UserX) {
        Intent(this@FavActivity, DetailUserActivity::class.java).apply {
            putExtra(DetailUserActivity.EXTRA_DETAIL, user.login)
        }.also {
            startActivity(it)
        }
    }

    private fun setTB(title: String) {
        setSupportActionBar(bind.tbFav)
        supportActionBar?.apply {
            setDisplayShowHomeEnabled(true)
            setDisplayHomeAsUpEnabled(true)
            this.title = title
        }
    }
}