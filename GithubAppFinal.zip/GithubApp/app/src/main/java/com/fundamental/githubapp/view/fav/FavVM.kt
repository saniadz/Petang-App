package com.fundamental.githubapp.view.fav

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import com.fundamental.githubapp.data.UsrEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FavVM @Inject constructor(private val repo: Repo) : ViewModel() {

    private val fav = MutableStateFlow(listOf<UsrEntity>())
    val favor = fav.asStateFlow()

    init {
        getFavUsers()
    }

    private fun getFavUsers() {
        viewModelScope.launch {
            repo.getFavList().collect {
                fav.value = it
            }
        }
    }
}