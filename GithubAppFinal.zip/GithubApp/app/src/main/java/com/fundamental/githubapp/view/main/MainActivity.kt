package com.fundamental.githubapp.view.main

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.fundamental.githubapp.R
import com.fundamental.githubapp.view.UserAdapter
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.remote.response.UserX
import com.fundamental.githubapp.databinding.ActivityMainBinding
import com.fundamental.githubapp.view.detail.DetailUserActivity.Companion.EXTRA_DETAIL
import com.fundamental.githubapp.utils.EspressoIdlingResource
import com.fundamental.githubapp.view.settings.SettingActivity
import com.fundamental.githubapp.view.detail.DetailUserActivity
import com.fundamental.githubapp.view.fav.FavActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private var _bind: ActivityMainBinding? = null
    private val bind get() = _bind!!

    private val mainVM: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        setSupportActionBar(bind.tbMain)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    mainVM.themeSet.collect { state ->
                        if (state) AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                        else AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    }
                }
                launch {
                    mainVM._usrs.collect { result ->
                        showUserSearch(result)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        EspressoIdlingResource.increment()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflatMenu = menuInflater
        inflatMenu.inflate(R.menu.menu, menu)

        val usrSearchManger = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val usrSearchView = menu.findItem(R.id.id_search).actionView as SearchView

        usrSearchView.apply {
            setSearchableInfo(usrSearchManger.getSearchableInfo(componentName))
            queryHint = getString(R.string.usr_uname)
            setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    EspressoIdlingResource.increment()
                    mainVM.userSearch(query ?: "")
                    clearFocus()
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return false
                }

            })
        }
        return true
    }

    override fun onOptionsItemSelected(mItem: MenuItem): Boolean {
        when (mItem.itemId) {
            R.id.id_fav -> {
                Intent(this@MainActivity, FavActivity::class.java).also {
                    startActivity(it)
                }
            }
            R.id.id_Theme -> {
                Intent(this@MainActivity, SettingActivity::class.java).also {
                    startActivity(it)
                }
            }
        }
        return super.onOptionsItemSelected(mItem)
    }

    override fun onDestroy() {
        _bind = null
        super.onDestroy()
    }

    private fun showError() {
        Toast.makeText(this@MainActivity, "An Error is Occurred", Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(loadData: Boolean) {
        if (loadData) {
            bind.pbMain.visibility = View.VISIBLE
            bind.rvList.visibility = View.GONE
        } else {
            bind.pbMain.visibility = View.GONE
            bind.rvList.visibility = View.VISIBLE
        }
    }

    private fun showUserSearch(usrResult: Result<ArrayList<UserX>>) {
        when (usrResult) {
            is Result.Loading -> showLoading(true)
            is Result.Error -> {
                showError()
                showLoading(false)
            }
            is Result.Success -> {
                bind.tvCount.text = getString(R.string.count, usrResult.data.size)
                val usrAdapter = UserAdapter(usrResult.data)

                bind.rvList.apply {
                    layoutManager = LinearLayoutManager(this@MainActivity)
                    adapter = usrAdapter
                    setHasFixedSize(true)
                }

                usrAdapter.setOnItemClickCallback(object : UserAdapter.OnItemClickCallback {
                    override fun onItemClicked(user: UserX) {
                        goToUsrDetail(user)
                    }

                })
                showLoading(false)
                EspressoIdlingResource.decrement()
            }
        }
    }

    private fun goToUsrDetail(usr: UserX) {
        Intent(this@MainActivity, DetailUserActivity::class.java).apply {
            putExtra(EXTRA_DETAIL, usr.login)
        }.also {
            startActivity(it)
        }
    }
}