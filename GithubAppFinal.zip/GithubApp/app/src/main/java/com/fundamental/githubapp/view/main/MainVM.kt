package com.fundamental.githubapp.view.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import com.fundamental.githubapp.data.Result
import com.fundamental.githubapp.data.remote.response.UserX
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainVM @Inject constructor(private val repo: Repo) : ViewModel() {

    val themeSet: Flow<Boolean> = repo.getSetTheme()

    private val usr = MutableStateFlow<Result<ArrayList<UserX>>>(Result.Loading)
    val _usrs = usr.asStateFlow()

    init {
        userSearch("\"\"")
    }

    fun userSearch(query: String) {
        usr.value = Result.Loading
        viewModelScope.launch {
            repo.userSearch(query).collect {
                usr.value = it
            }
        }
    }
}