package com.fundamental.githubapp.view.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fundamental.githubapp.setting.Repo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingVM @Inject constructor(private val repo: Repo) :
    ViewModel() {
    val getSetTheme: Flow<Boolean> = repo.getSetTheme()

    fun saveSetTheme(darkModeState: Boolean) {
        viewModelScope.launch {
            repo.saveThemeSet(darkModeState)
        }
    }
}